package xatirchi.uz.xatirchi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XatirchiApplicationTests {

    @Test
    void contextLoads() {
    }

}
