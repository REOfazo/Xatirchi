package xatirchi.uz.xatirchi.role;

public enum Role {
    GUEST,
    USER,
    ADMIN,
    SUPERUSER;

   public String getRole() {
       return this.name();
   }
}