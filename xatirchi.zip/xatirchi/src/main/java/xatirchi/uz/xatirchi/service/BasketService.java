package xatirchi.uz.xatirchi.service;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import xatirchi.uz.xatirchi.basket.Basket;
import xatirchi.uz.xatirchi.message.MessageStatus;
import xatirchi.uz.xatirchi.message.SendMessage;
import xatirchi.uz.xatirchi.repository.BasketRepository;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

@Service
@Transactional

public class BasketService implements Serializable {

    @Autowired
    private final BasketRepository basketRepository;

    public BasketService(BasketRepository basketRepository) {
        this.basketRepository = basketRepository;
    }

    public List<Basket> getAll() {
        return basketRepository.findAll();
    }

    public ResponseEntity<SendMessage> delete(UUID id) {
        basketRepository.deleteById(id);
        return ResponseEntity.ok(new SendMessage("Tanlangan element o'chirib tashlandi!", MessageStatus.OK));
    }
}
