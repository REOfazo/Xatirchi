package xatirchi.uz.xatirchi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import xatirchi.uz.xatirchi.adress.UserAddress;

import java.util.UUID;

public interface UserAddressRepository extends JpaRepository<UserAddress, UUID> {
}
