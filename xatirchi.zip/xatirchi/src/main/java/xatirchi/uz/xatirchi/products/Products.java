package xatirchi.uz.xatirchi.products;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import xatirchi.uz.xatirchi.image_content.ImageContent;
import xatirchi.uz.xatirchi.status.Status;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "products")

public class Products {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "product_name", nullable = false)
    private String productName;

    @Column(name = "product_price", nullable = false)
    private double productPrice;

    @Column(name = "product_color", nullable = false)
    private String productColor;

    @Column(name = "product_quantity", nullable = false)
    private int productQuantity;                // mahsulot miqdori

    @Column(name = "product_discount")
    private float productDiscount;              // mahsulot chegirmasi

    @Column(name = "product_images")
    @OneToMany
    private List<ImageContent> imageContent;

    @Column(name = "product_comment")
    private String productComment;

    @Column(name = "product_create_time")
    @CreationTimestamp
    private LocalDateTime productCreateTime;
}
