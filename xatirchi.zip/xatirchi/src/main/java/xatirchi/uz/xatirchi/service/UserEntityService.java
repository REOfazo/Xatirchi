package xatirchi.uz.xatirchi.service;


import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import xatirchi.uz.xatirchi.entity.UserEntity;
import xatirchi.uz.xatirchi.message.MessageStatus;
import xatirchi.uz.xatirchi.message.SendMessage;
import xatirchi.uz.xatirchi.repository.UserEntityRepository;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class UserEntityService implements Serializable {

    @Autowired
    private final UserEntityRepository userEntityRepository;

    public UserEntityService(UserEntityRepository userEntityRepository) {
        this.userEntityRepository = userEntityRepository;
    }

    public ResponseEntity<SendMessage> getOneUser(UUID id) {
        return ResponseEntity.ok(new SendMessage(userEntityRepository.findById(id).toString(), MessageStatus.OK));
    }

    public List<UserEntity> getAllUsers() {
        return userEntityRepository.findAll();
    }

    public ResponseEntity<SendMessage> save(UserEntity userEntity) {
        UserEntity user = new UserEntity();

        user.setUserName(userEntity.getUserName());
        user.setUserRole(userEntity.getUserRole());
        user.setEMail(userEntity.getEMail());
        user.setFirstName(userEntity.getFirstName());
        user.setStatus(userEntity.getStatus());
        user.setPassword(userEntity.getPassword());
        user.setLastName(userEntity.getLastName());
        user.setPhoneNumber(userEntity.getPhoneNumber());
        user.setPassportSeries(userEntity.getPassportSeries());

        userEntityRepository.save(user);

        return ResponseEntity.ok(new SendMessage("User muvaffaqiyatli qo'shildi!", MessageStatus.OK));
    }

    public ResponseEntity<SendMessage> update(UUID id, UserEntity userEntity) {
        UserEntity user = new UserEntity();
        userEntityRepository.findById(id);

        user.setId(id);
        user.setUserRole(userEntity.getUserRole());
        user.setUserName(userEntity.getUserName());
        user.setPassword(userEntity.getPassword());
        user.setEMail(userEntity.getEMail());
        user.setPhoneNumber(userEntity.getPhoneNumber());
        user.setPassportSeries(userEntity.getPassportSeries());
        user.setFirstName(userEntity.getFirstName());
        user.setLastName(userEntity.getLastName());
        user.setStatus(userEntity.getStatus());

        userEntityRepository.save(user);

        return ResponseEntity.ok(new SendMessage("User ma'lumotlari muvaffaqiyatli o'zgartirildi!", MessageStatus.OK));
    }

    public ResponseEntity<SendMessage> delete(UUID id) {

        userEntityRepository.deleteById(id);

        return ResponseEntity.ok(new SendMessage("Tanlangan 'User' muvaffaqiyatli o'chirildi!", MessageStatus.OK));
    }
}
