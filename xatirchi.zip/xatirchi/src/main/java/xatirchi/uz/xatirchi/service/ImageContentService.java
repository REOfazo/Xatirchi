package xatirchi.uz.xatirchi.service;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import xatirchi.uz.xatirchi.image_content.ImageContent;
import xatirchi.uz.xatirchi.message.MessageStatus;
import xatirchi.uz.xatirchi.message.SendMessage;
import xatirchi.uz.xatirchi.repository.ImageContentRepository;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Transactional

public class ImageContentService implements Serializable {
    @Autowired
    private final ImageContentRepository imageContentRepository;

    public ImageContentService(ImageContentRepository imageContentRepository) {
        this.imageContentRepository = imageContentRepository;
    }

    public List<ImageContent> getAll() {
        return imageContentRepository.findAll();
    }

    public Optional<ImageContent> getOne(UUID id) {
        return imageContentRepository.findById(id);
    }

    public ResponseEntity<SendMessage> save(ImageContent imageContent) {
        imageContentRepository.save(imageContent);
        return ResponseEntity.ok(new SendMessage("Fayl saqlandi!", MessageStatus.OK));
    }

    public ResponseEntity<SendMessage> update(UUID id, ImageContent imageContent) {
        ImageContent imageContent1 = new ImageContent();

        imageContent1.setId(id);
        imageContent1.setImageContent(imageContent.getImageContent());
        imageContent1.setImageExtension(imageContent.getImageExtension());
        imageContent1.setImageUrl(imageContent.getImageUrl());
        imageContent1.setImageSize(imageContent.getImageSize());
        imageContent1.setImageOriginalName(imageContent.getImageOriginalName());

        imageContentRepository.save(imageContent1);

        return ResponseEntity.ok(new SendMessage("Fayl tahrirlandi!", MessageStatus.OK));
    }

    public ResponseEntity<SendMessage> delete(UUID id) {
        imageContentRepository.deleteById(id);
        return ResponseEntity.ok(new SendMessage("Fayl o'chirildi!", MessageStatus.OK));
    }

    public ResponseEntity<SendMessage> deleteAll() {
        imageContentRepository.deleteAll();
        return ResponseEntity.ok(new SendMessage("Bazadan barcha rasmlar tozalandi!", MessageStatus.OK));
    }
}
