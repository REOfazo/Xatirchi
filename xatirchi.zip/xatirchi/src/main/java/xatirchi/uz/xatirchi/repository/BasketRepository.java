package xatirchi.uz.xatirchi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import xatirchi.uz.xatirchi.basket.Basket;

import java.util.UUID;

public interface BasketRepository extends JpaRepository<Basket, UUID> {
}
