package xatirchi.uz.xatirchi.payment;

public enum PaymentStatus {
    UNPAID,
    PAID
}
