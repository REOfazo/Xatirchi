package xatirchi.uz.xatirchi.payment;

public enum PaymentMethod {
    PAY_IN_CASH
}
