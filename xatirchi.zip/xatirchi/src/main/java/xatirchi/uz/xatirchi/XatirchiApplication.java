package xatirchi.uz.xatirchi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XatirchiApplication {

    public static void main(String[] args) {
        SpringApplication.run(XatirchiApplication.class, args);
    }

}
