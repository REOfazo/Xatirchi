package xatirchi.uz.xatirchi.order;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import xatirchi.uz.xatirchi.adress.UserAddress;
import xatirchi.uz.xatirchi.entity.UserEntity;
import xatirchi.uz.xatirchi.payment.PaymentMethod;
import xatirchi.uz.xatirchi.payment.PaymentStatus;
import xatirchi.uz.xatirchi.products.Products;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "user_id")
    @ManyToMany
    private List<UserEntity> userId;

    @Column(name = "address")
    @ManyToMany
    private List<UserAddress> userAddress;

    @Column(name = "products")
    @ManyToMany
    private List<Products> products;

    @Column(name = "payment_method")
    private PaymentMethod paymentMethod;

    @Column(name = "payment_status")
    private PaymentStatus paymentStatus;

    @Column(name = "payment_time")
    @CreationTimestamp
    private LocalDateTime paymentTime;
}
