package xatirchi.uz.xatirchi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import xatirchi.uz.xatirchi.entity.UserEntity;
import xatirchi.uz.xatirchi.service.UserEntityService;

import java.util.Iterator;

@Controller
@RequestMapping("/api")

public class Index {

    @Autowired
    private final UserEntityService userEntityService;

    public Index(UserEntityService userEntity) {
        this.userEntityService = userEntity;
    }

    @GetMapping("/index")
    public String index() {
        return "form";
    }
    @PostMapping("/login")
    public String login(@RequestParam String userName, @RequestParam String password) {
        Iterator<UserEntity> iterator = userEntityService.getAllUsers().iterator();
        UserEntity user;

        while (iterator.hasNext()) {
            user = iterator.next();
            if (userName.equals(user.getUserName()) && password.equals(user.getPassword()))
                return "index";
        }
        return "form";
    }
    @PostMapping("/createuser")
    public String createUser(@ModelAttribute UserEntity user) {
        userEntityService.save(user);
        return "form";
    }
    @GetMapping("/carousel")
    public String carousel() {
        return "carousel";
    }
}
