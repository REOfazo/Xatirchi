package xatirchi.uz.xatirchi.status;

public enum Status {
    DISABLE,
    ACTIVE
}
