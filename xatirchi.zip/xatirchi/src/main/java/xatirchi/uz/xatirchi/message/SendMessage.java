package xatirchi.uz.xatirchi.message;


import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@ToString

public class SendMessage {
    private String content;
    private MessageStatus messageStatus;
}
