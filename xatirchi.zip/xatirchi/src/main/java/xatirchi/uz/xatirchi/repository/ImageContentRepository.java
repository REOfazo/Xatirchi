package xatirchi.uz.xatirchi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import xatirchi.uz.xatirchi.image_content.ImageContent;

import java.util.Optional;
import java.util.UUID;

public interface ImageContentRepository extends JpaRepository<ImageContent, UUID> {

}
