package xatirchi.uz.xatirchi.message;

public enum MessageStatus {
    ERROR,
    OK
}
