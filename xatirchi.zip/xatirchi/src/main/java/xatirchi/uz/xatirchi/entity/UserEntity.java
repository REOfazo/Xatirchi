package xatirchi.uz.xatirchi.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import xatirchi.uz.xatirchi.role.Role;
import xatirchi.uz.xatirchi.status.Status;

import java.util.UUID;

@Entity
@Table(name = "user_entity")
@NoArgsConstructor
@AllArgsConstructor
@Data

public class UserEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "first_name", nullable = false)
    private String firstName;

    @Column(name = "last_name", nullable = false)
    private String lastName;

    @Column(name = "phone_number", nullable = false)
    private String phoneNumber;

    @Column(name = "user_name", nullable = false)
    private String userName;

    @Column(name = "passsword", nullable = false)
    private String password;

    @Column(name = "e_mail")
    private String eMail;

    @Column(name = "passport_series")
    private String passportSeries;

    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    private Status status;

    @Column(name = "user_role")
    @Enumerated(EnumType.STRING)
    private Role userRole;
}
