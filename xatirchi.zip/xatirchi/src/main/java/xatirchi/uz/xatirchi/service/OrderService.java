package xatirchi.uz.xatirchi.service;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import xatirchi.uz.xatirchi.message.MessageStatus;
import xatirchi.uz.xatirchi.message.SendMessage;
import xatirchi.uz.xatirchi.order.Order;
import xatirchi.uz.xatirchi.repository.OrderRepository;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

@Service
@Transactional

public class OrderService implements Serializable {
    @Autowired
    private final OrderRepository orderRepository;

    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public List<Order> getAll() {
        return orderRepository.findAll();
    }

    public Order getOne(UUID id) {
        return orderRepository.getById(id);
    }

    public ResponseEntity<SendMessage> save(Order order) {
        orderRepository.save(order);
        return ResponseEntity.ok(new SendMessage("Saqlandi!", MessageStatus.OK));
    }

    public ResponseEntity<SendMessage> update(UUID id, Order order) {
        Order order1 = new Order();

        order1.setId(id);
        order1.setPaymentStatus(order.getPaymentStatus());
        order1.setPaymentMethod(order.getPaymentMethod());
        order1.setPaymentTime(order.getPaymentTime());
        order1.setId(id);
        order1.setUserId(order.getUserId());
        order1.setUserAddress(order.getUserAddress());

        orderRepository.save(order1);

        return ResponseEntity.ok(new SendMessage("Ma'lumot o'zgartirildi!", MessageStatus.OK));
    }

    public ResponseEntity<SendMessage> delete(UUID id) {
        orderRepository.deleteById(id);
        return ResponseEntity.ok(new SendMessage("Ma'lumot o'chirildi!", MessageStatus.OK));
    }

    public ResponseEntity<SendMessage> deleteAll() {
        orderRepository.deleteAll();
        return ResponseEntity.ok(new SendMessage("Baza tozalandi!", MessageStatus.OK));
    }
}
