package xatirchi.uz.xatirchi.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/user-entity")

public class UserEntityController {

}
