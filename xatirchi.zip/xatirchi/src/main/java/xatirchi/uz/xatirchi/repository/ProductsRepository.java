package xatirchi.uz.xatirchi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import xatirchi.uz.xatirchi.products.Products;

import java.util.UUID;

public interface ProductsRepository extends JpaRepository<Products, UUID> {
}
