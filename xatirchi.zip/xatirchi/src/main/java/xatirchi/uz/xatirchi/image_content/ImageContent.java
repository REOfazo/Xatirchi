package xatirchi.uz.xatirchi.image_content;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "image_content")
public class ImageContent {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "image_original_name")
    private String imageOriginalName;

    @Column(name = "image_extension")
    private String imageExtension;

    @Column(name = "image_content")
    private byte[] imageContent;

    @Column(name = "image_url")
    private String imageUrl;

    @Column(name = "image_size")
    private Long ImageSize;
}
