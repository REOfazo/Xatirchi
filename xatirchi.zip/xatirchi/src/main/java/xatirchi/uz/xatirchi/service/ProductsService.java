package xatirchi.uz.xatirchi.service;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import xatirchi.uz.xatirchi.message.MessageStatus;
import xatirchi.uz.xatirchi.message.SendMessage;
import xatirchi.uz.xatirchi.products.Products;
import xatirchi.uz.xatirchi.repository.ProductsRepository;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

@Service
@Transactional

public class ProductsService implements Serializable {
    @Autowired
    private final ProductsRepository productsRepository;

    public ProductsService(ProductsRepository productsRepository) {
        this.productsRepository = productsRepository;
    }

    public List<Products> getAll() {
        return productsRepository.findAll();
    }

    public Products getOne(UUID id) {
        return productsRepository.getOne(id);
    }

    public ResponseEntity<SendMessage> save(Products products) {
        productsRepository.save(products);
        return ResponseEntity.ok(new SendMessage("Ma'lumot saqlandi!", MessageStatus.OK));
    }

    public ResponseEntity<SendMessage> update(UUID id, Products products) {
        Products products1 = new Products();

        products1.setId(id);
        products1.setProductColor(products.getProductColor());
        products1.setProductComment(products.getProductComment());
        products1.setProductDiscount(products.getProductDiscount());
        products1.setProductName(products.getProductName());
        products1.setProductPrice(products.getProductPrice());
        products1.setProductQuantity(products.getProductQuantity());
        products1.setProductCreateTime(products.getProductCreateTime());
        products1.setImageContent(products.getImageContent());

        productsRepository.save(products1);

        return ResponseEntity.ok(new SendMessage("Ma'lumot o'zgartirildi!", MessageStatus.OK));
    }

    public ResponseEntity<SendMessage> delete(UUID id) {
        productsRepository.deleteById(id);
        return ResponseEntity.ok(new SendMessage("Tanlangan ma'lumot o'chirildi!", MessageStatus.OK));
    }

    public ResponseEntity<SendMessage> deleteAll() {
        productsRepository.deleteAll();
        return ResponseEntity.ok(new SendMessage("Baza tozalandi!", MessageStatus.OK));
    }
}
