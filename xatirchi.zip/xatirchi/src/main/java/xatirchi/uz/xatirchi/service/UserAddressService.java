package xatirchi.uz.xatirchi.service;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import xatirchi.uz.xatirchi.adress.UserAddress;
import xatirchi.uz.xatirchi.message.MessageStatus;
import xatirchi.uz.xatirchi.message.SendMessage;
import xatirchi.uz.xatirchi.repository.UserAddressRepository;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

@Service
@Transactional

public class UserAddressService implements Serializable {

    @Autowired
    private final UserAddressRepository userAddressRepository;

    public UserAddressService(UserAddressRepository userAddressRepository) {
        this.userAddressRepository = userAddressRepository;
    }

    public ResponseEntity<SendMessage> getOneAddress(UUID id) {

        return ResponseEntity.ok(new SendMessage(userAddressRepository.findById(id).toString(), MessageStatus.OK));
    }

    public ResponseEntity<List<UserAddress>> getAllAddress() {
        return ResponseEntity.ok(userAddressRepository.findAll());
    }

    public ResponseEntity<SendMessage> save(UserAddress userAddress) {
        userAddressRepository.save(userAddress);
        return ResponseEntity.ok(new SendMessage("Yangi manzil muvaffaqiyatli saqlandi!", MessageStatus.OK));
    }

    public ResponseEntity<SendMessage> update(UUID id, UserAddress userAddress) {
        UserAddress userAddress1 = new UserAddress();

        userAddress1.setId(userAddress.getId());
        userAddress1.setCountry(userAddress.getCountry());
        userAddress1.setStreet(userAddress.getStreet());
        userAddress1.setRegion(userAddress.getRegion());
        userAddress1.setHomeNumber(userAddress.getHomeNumber());
        userAddress1.setPostalCode(userAddress.getPostalCode());

        userAddressRepository.save(userAddress1);

        return ResponseEntity.ok(new SendMessage("Manzil muvaffaqiyatli o'zgartirildi!", MessageStatus.OK));
    }

    public ResponseEntity<SendMessage> delete(UUID id) {
        userAddressRepository.deleteById(id);
        return ResponseEntity.ok(new SendMessage("Manzil muvaffaqiyatli o'chirildi!", MessageStatus.OK));
    }
}
